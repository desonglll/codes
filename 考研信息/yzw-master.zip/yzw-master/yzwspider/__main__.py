#!/usr/bin/python
import yzwspider.commands.cmd as command

command.run()