/**
 * Created by Rebecca_Han on 16/10/26.
 */
module.exports = {

}

var process= {
    "id": 1,
        "data": [
        {
            "question1_id": 1,
            "answer1_id": 1,
            "feed1_source_id": 1,
            "feed1_source_name": "001",
            "feed1_source_img": "https://i.loli.net/2021/08/18/clDYXzjvAWagIUO.png",
            "question1": "入党申请",
            "answer1_ctnt": "入党申请是第一步",
        },
        {
            "question1_id": 2,
            "answer1_id": 2,
            "feed1_source_id": 2,
            "feed1_source_name": "002",
            "feed1_source_img": "https://i.loli.net/2021/08/18/pXINuo32G9TUvdA.png",
            "question1": "入党积极分子",
            "answer1_ctnt": "入党申请满六个月后成为入党积极分子",
        },
        {
            "question1_id": 3,
            "answer1_id": 3,
            "feed1_source_id": 3,
            "feed1_source_name": "003",
            "feed1_source_img": "https://s3.bmp.ovh/imgs/2021/08/75b6b2e4589d8fe1.png",
            "question1": "发展对象",
            "answer1_ctnt": "入党积极分子培养一年后成为发展对象",
        },
        {
            "question1_id": 4,
            "answer1_id": 4,
            "feed1_source_id": 4,
            "feed1_source_name": "004",
            "feed1_source_img": "https://s3.bmp.ovh/imgs/2021/08/d3798393a0dde7be.png",
            "question1": "预备党员",
            "answer1_ctnt": "发展对象约一个月后成为预备党员",
        },
        {
            "question1_id": 5,
            "answer1_id": 5,
            "feed1_source_id": 5,
            "feed1_source_name": "005",
            "feed1_source_img": "https://i.loli.net/2021/08/18/clDYXzjvAWagIUO.png",
            "question1": "正式党员",
            "answer1_ctnt": "预备党员一年后转正为正式党员",
        }

    ]

}

module.exports.process = process;