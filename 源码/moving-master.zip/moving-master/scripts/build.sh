set -e

echo "Building the example site..."
bundle exec jekyll build