set -e

gem install bundler
bundle install