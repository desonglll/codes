// require("esbuild-register");

const config = require("./config/index.js");
module.exports = config.default;
