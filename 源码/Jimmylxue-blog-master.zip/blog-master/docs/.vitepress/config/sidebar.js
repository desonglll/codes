import { getMsg } from "./util";

export default {
  "/": getMsg(),
};
