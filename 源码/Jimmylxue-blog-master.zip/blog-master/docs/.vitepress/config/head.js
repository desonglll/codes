const head = [
	[
		'link',
		{
			rel: 'icon',
			href: 'https://vitepress-source.oss-cn-beijing.aliyuncs.com/typoraimage-20220326203849385.png',
		},
	],
]

export default head
