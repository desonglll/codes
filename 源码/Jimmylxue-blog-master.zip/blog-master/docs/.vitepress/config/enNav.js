const enNav = [
    { text: 'Design disciplines', link: '/en-US/design' },
    { text: 'Component', link: '/en-US/' },
    { text: 'Version history', link: '/en-US/version' },
    { text: 'Theme', link: '/en-US/theme' },
  ]
  
  export default enNav