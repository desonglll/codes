# 03-sunnyside
Frontend Mentor Project. Sunnyside Agency Landing Page

Sunnyside Agency Landing Page - "...a test of your layout and responsive skills. There's a tiny bit of JS for the mobile menu, but the focus is HTML & CSS."

https://www.frontendmentor.io/challenges/sunnyside-agency-landing-page-7yVs3B6ef
