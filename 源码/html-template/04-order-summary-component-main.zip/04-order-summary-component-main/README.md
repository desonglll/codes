# 04-order-summary-component
 Order Summary Component challenge by Frontend Mentor: "... a perfect project for newbies who are starting to build confidence with layouts!"

https://www.frontendmentor.io/challenges/order-summary-component-QlPmajDUj
